/*
 * GeekOS - x86 version information
 *
 * Copyright (C) 2001-2008, David H. Hovemeyer <david.hovemeyer@gmail.com>
 */

#ifndef ARCH_VERSION_H
#define ARCH_VERSION_H

#define GEEKOS_ARCH "x86"

#endif /* ARCH_VERSION_H */
