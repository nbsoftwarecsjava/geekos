/*
 * GeekOS - ATA support
 */

void ata_init(void);
